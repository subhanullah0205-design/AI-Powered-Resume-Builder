import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController(), _pass = TextEditingController();
  bool _register = false, _busy = false;

  Future<void> _submit() async {
    setState(() => _busy = true);
    try {
      _register
          ? await FirebaseService.register(_email.text.trim(), _pass.text)
          : await FirebaseService.login(_email.text.trim(), _pass.text);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              const Icon(Icons.description, size: 72, color: Colors.blue),
              const SizedBox(height: 8),
              Text('AI Resume Builder', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 24),
              TextField(controller: _email, keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: _pass, obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity,
                  child: FilledButton(onPressed: _busy ? null : _submit,
                      child: Text(_busy ? 'Please wait...' : (_register ? 'Sign up' : 'Log in')))),
              TextButton(onPressed: () => setState(() => _register = !_register),
                  child: Text(_register ? 'Have an account? Log in' : 'New here? Sign up')),
            ]),
          ),
        ),
      );
}
