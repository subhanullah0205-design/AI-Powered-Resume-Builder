import 'package:flutter/material.dart';
import '../models.dart';
import '../services/ai_service.dart';
import '../services/firebase_service.dart';
import 'preview_screen.dart';

class EditorScreen extends StatefulWidget {
  final Resume resume;
  const EditorScreen({super.key, required this.resume});
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final Resume r = widget.resume;
  late final Map<String, TextEditingController> c = {
    'title': TextEditingController(text: r.title), 'name': TextEditingController(text: r.name),
    'email': TextEditingController(text: r.email), 'phone': TextEditingController(text: r.phone),
    'role': TextEditingController(text: r.role), 'summary': TextEditingController(text: r.summary),
    'skills': TextEditingController(text: r.skills), 'experience': TextEditingController(text: r.experience),
    'education': TextEditingController(text: r.education),
  };
  bool _busy = false;

  void _msg(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  void _sync() {
    r.title = c['title']!.text; r.name = c['name']!.text; r.email = c['email']!.text;
    r.phone = c['phone']!.text; r.role = c['role']!.text; r.summary = c['summary']!.text;
    r.skills = c['skills']!.text; r.experience = c['experience']!.text; r.education = c['education']!.text;
  }

  Future<void> _ai(String field, Future<String> Function() job) async {
    _sync();
    if (r.role.trim().isEmpty) return _msg('Enter your target job role first');
    setState(() => _busy = true);
    try { c[field]!.text = await job(); } catch (e) { _msg('$e'); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _import() async {
    final t = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Import from LinkedIn'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Open your LinkedIn profile, copy the About, Experience and Education text (or the text of '
            'More > Save to PDF) and paste it here. AI will fill the fields.', style: TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        TextField(controller: t, maxLines: 8, decoration: const InputDecoration(border: OutlineInputBorder())),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Import')),
      ],
    ));
    if (ok != true || t.text.trim().isEmpty) return;
    setState(() => _busy = true);
    try {
      final m = await AiService.parseProfile(t.text);
      for (final k in ['name', 'email', 'phone', 'role', 'summary', 'skills', 'experience', 'education']) {
        final v = '${m[k] ?? ''}'.trim();
        if (v.isNotEmpty) c[k]!.text = v;
      }
    } catch (e) { _msg('$e'); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _save({bool preview = false}) async {
    _sync();
    try {
      r.id = await FirebaseService.save(r);
      if (!mounted) return;
      if (preview) {
        Navigator.push(context, MaterialPageRoute(builder: (_) => PreviewScreen(resume: r)));
      } else { _msg('Saved'); }
    } catch (e) { _msg('$e'); }
  }

  Widget _f(String k, String label, {int lines = 1, String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(controller: c[k], minLines: lines, maxLines: lines == 1 ? 1 : lines + 3,
            decoration: InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder())),
      );

  Widget _aiBtn(String text, VoidCallback f) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: OutlinedButton.icon(onPressed: _busy ? null : f, icon: const Icon(Icons.auto_awesome), label: Text(text)),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Edit resume'), actions: [
          IconButton(icon: const Icon(Icons.save), onPressed: _busy ? null : () => _save()),
        ]),
        body: Stack(children: [
          ListView(padding: const EdgeInsets.all(16), children: [
            FilledButton.tonalIcon(onPressed: _busy ? null : _import,
                icon: const Icon(Icons.download), label: const Text('Import from LinkedIn')),
            const SizedBox(height: 16),
            _f('title', 'Resume title'), _f('name', 'Full name'), _f('email', 'Email'), _f('phone', 'Phone'),
            _f('role', 'Target job role (e.g. Flutter Developer)'),
            _f('skills', 'Skills (comma separated)'),
            _aiBtn('AI: suggest skills for this role', () => _ai('skills', () => AiService.suggestSkills(r))),
            _f('experience', 'Experience', lines: 5, hint: 'Title - Company (dates)\n- what you did'),
            _aiBtn('AI: improve my experience', () => _ai('experience', () => AiService.improveExperience(r))),
            _f('summary', 'Professional summary', lines: 4),
            _aiBtn('AI: generate summary', () => _ai('summary', () => AiService.summary(r))),
            _f('education', 'Education', lines: 3, hint: 'BS Computer Engineering - COMSATS (2023-2027)'),
            FilledButton.icon(onPressed: _busy ? null : () => _save(preview: true),
                icon: const Icon(Icons.picture_as_pdf), label: const Text('Choose template & export PDF')),
          ]),
          if (_busy) Container(color: Colors.black26, child: const Center(child: CircularProgressIndicator())),
        ]),
      );
}
