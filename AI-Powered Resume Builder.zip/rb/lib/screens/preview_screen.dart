import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import '../models.dart';
import '../services/firebase_service.dart';
import '../services/pdf_service.dart';

class PreviewScreen extends StatefulWidget {
  final Resume resume;
  const PreviewScreen({super.key, required this.resume});
  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  @override
  Widget build(BuildContext context) {
    final r = widget.resume;
    return Scaffold(
      appBar: AppBar(title: const Text('Template & PDF')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Wrap(spacing: 8, children: templates.map((t) => ChoiceChip(
                label: Text(t[0].toUpperCase() + t.substring(1)),
                selected: r.template == t,
                onSelected: (_) { setState(() => r.template = t); FirebaseService.save(r); },
              )).toList()),
        ),
        // PdfPreview has built-in Share / Print / Save-as-PDF buttons
        Expanded(
          child: PdfPreview(
            key: ValueKey(r.template),
            build: (_) => PdfService.build(r, r.template),
            pdfFileName: '${r.name.isEmpty ? 'resume' : r.name.replaceAll(' ', '_')}_resume.pdf',
            canChangePageFormat: false, canChangeOrientation: false, canDebug: false,
          ),
        ),
      ]),
    );
  }
}
