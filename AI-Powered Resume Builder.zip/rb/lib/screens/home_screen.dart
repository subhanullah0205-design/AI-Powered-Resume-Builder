import 'package:flutter/material.dart';
import '../models.dart';
import '../services/firebase_service.dart';
import 'editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('My Resumes'), actions: [
          IconButton(icon: const Icon(Icons.logout), onPressed: FirebaseService.logout),
        ]),
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.add), label: const Text('New resume'),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => EditorScreen(resume: Resume()))),
        ),
        body: StreamBuilder<List<Resume>>(
          stream: FirebaseService.resumes(),
          builder: (c, s) {
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            if (s.data!.isEmpty) return const Center(child: Text('No resumes yet. Tap "New resume".'));
            return ListView(padding: const EdgeInsets.all(12), children: s.data!.map((r) => Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.description)),
                    title: Text(r.title.isEmpty ? 'Untitled' : r.title),
                    subtitle: Text('${r.name}  •  ${r.role}'),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline),
                        onPressed: () => FirebaseService.delete(r.id)),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => EditorScreen(resume: r))),
                  ),
                )).toList());
          },
        ),
      );
}
