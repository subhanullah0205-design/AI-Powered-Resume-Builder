class Resume {
  String id, title, name, email, phone, role, summary, skills, experience, education, template;
  Resume({this.id = '', this.title = 'My Resume', this.name = '', this.email = '', this.phone = '',
      this.role = '', this.summary = '', this.skills = '', this.experience = '',
      this.education = '', this.template = 'modern'});

  Map<String, dynamic> toMap() => {
        'title': title, 'name': name, 'email': email, 'phone': phone, 'role': role,
        'summary': summary, 'skills': skills, 'experience': experience,
        'education': education, 'template': template,
      };

  factory Resume.fromMap(String id, Map<String, dynamic> m) => Resume(
        id: id, title: m['title'] ?? 'My Resume', name: m['name'] ?? '', email: m['email'] ?? '',
        phone: m['phone'] ?? '', role: m['role'] ?? '', summary: m['summary'] ?? '',
        skills: m['skills'] ?? '', experience: m['experience'] ?? '',
        education: m['education'] ?? '', template: m['template'] ?? 'modern',
      );
}
