import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models.dart';

/// Run with: flutter run --dart-define=OPENAI_KEY=sk-...
/// NOTE: a key inside an app can be extracted. For production, call OpenAI from a
/// Firebase Cloud Function and keep the key on the server.
class AiService {
  static const _key = String.fromEnvironment('OPENAI_KEY');
  static const _model = 'gpt-4o-mini';

  static Future<String> _chat(String system, String user, {bool json = false}) async {
    if (_key.isEmpty) throw Exception('OPENAI_KEY not set (see README)');
    final r = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $_key'},
      body: jsonEncode({
        'model': _model,
        'messages': [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}],
        if (json) 'response_format': {'type': 'json_object'},
      }),
    ).timeout(const Duration(seconds: 40));
    if (r.statusCode != 200) throw Exception('OpenAI error ${r.statusCode}');
    return (jsonDecode(utf8.decode(r.bodyBytes))['choices'][0]['message']['content'] as String).trim();
  }

  static Future<String> summary(Resume r) => _chat(
      'You write concise, professional resume summaries (3 sentences, no first-person pronouns).',
      'Target role: ${r.role}\nSkills: ${r.skills}\nExperience: ${r.experience}\nEducation: ${r.education}');

  static Future<String> improveExperience(Resume r) => _chat(
      'Rewrite resume experience as strong bullet points starting with action verbs. Keep every fact; '
      'do not invent employers, dates or numbers. Format: a line "Title - Company (dates)" then lines starting with "- ".',
      'Target role: ${r.role}\nExperience:\n${r.experience}');

  static Future<String> suggestSkills(Resume r) => _chat(
      'Return only a comma-separated list of 12 relevant skills for the role, no extra text.',
      'Role: ${r.role}\nCurrent skills: ${r.skills}');

  /// LinkedIn import: the user pastes profile text (About/Experience/Education sections or the profile PDF text).
  static Future<Map<String, dynamic>> parseProfile(String text) async {
    final out = await _chat(
        'Extract resume data from the text. Return JSON with string keys: name, email, phone, role, summary, '
        'skills (comma separated), experience (lines "Title - Company (dates)" followed by "- " bullets), '
        'education (lines "Degree - School (years)"). Use "" for anything missing; never invent data.',
        text, json: true);
    return jsonDecode(out) as Map<String, dynamic>;
  }
}
