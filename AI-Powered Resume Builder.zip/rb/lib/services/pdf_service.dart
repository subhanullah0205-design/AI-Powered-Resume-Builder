import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models.dart';

const templates = ['modern', 'classic', 'minimal'];

class PdfService {
  static Future<Uint8List> build(Resume r, String template) async {
    final modern = template == 'modern', minimal = template == 'minimal';
    final accent = modern ? PdfColors.blue800 : (minimal ? PdfColors.grey700 : PdfColors.black);
    final centered = minimal;

    List<String> lines(String s) => s.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

    pw.Widget section(String title, List<pw.Widget> body) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.SizedBox(height: 14),
            pw.Text(minimal ? title.toUpperCase() : title,
                style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: accent,
                    letterSpacing: minimal ? 2 : 0)),
            pw.Divider(color: accent, thickness: 0.8),
            ...body,
          ],
        );

    List<pw.Widget> entries(String s) => lines(s).map((l) {
          final bullet = l.startsWith('-') || l.startsWith('•');
          return bullet
              ? pw.Padding(
                  padding: const pw.EdgeInsets.only(left: 10, top: 2),
                  child: pw.Text('•  ${l.substring(1).trim()}', style: const pw.TextStyle(fontSize: 11)))
              : pw.Padding(
                  padding: const pw.EdgeInsets.only(top: 6),
                  child: pw.Text(l, style: pw.TextStyle(fontSize: 11.5, fontWeight: pw.FontWeight.bold)));
        }).toList();

    final contact = [r.email, r.phone].where((e) => e.isNotEmpty).join('   |   ');
    final header = pw.Container(
      width: double.infinity,
      color: modern ? PdfColors.blue800 : null,
      padding: pw.EdgeInsets.all(modern ? 20 : 0),
      child: pw.Column(
        crossAxisAlignment: centered ? pw.CrossAxisAlignment.center : pw.CrossAxisAlignment.start,
        children: [
          pw.Text(r.name, style: pw.TextStyle(fontSize: 26, fontWeight: pw.FontWeight.bold,
              color: modern ? PdfColors.white : PdfColors.black)),
          if (r.role.isNotEmpty)
            pw.Text(r.role, style: pw.TextStyle(fontSize: 14, color: modern ? PdfColors.white : accent)),
          pw.SizedBox(height: 4),
          pw.Text(contact, style: pw.TextStyle(fontSize: 10.5, color: modern ? PdfColors.white : PdfColors.grey800)),
        ],
      ),
    );

    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        header,
        if (r.summary.trim().isNotEmpty) section('Summary', [pw.Text(r.summary, style: const pw.TextStyle(fontSize: 11))]),
        if (r.skills.trim().isNotEmpty) section('Skills', [pw.Text(r.skills, style: const pw.TextStyle(fontSize: 11))]),
        if (r.experience.trim().isNotEmpty) section('Experience', entries(r.experience)),
        if (r.education.trim().isNotEmpty) section('Education', entries(r.education)),
      ],
    ));
    return doc.save();
  }
}
