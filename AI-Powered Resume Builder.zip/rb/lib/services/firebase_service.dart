import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models.dart';

class FirebaseService {
  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;
  static User get user => _auth.currentUser!;
  static Stream<User?> get authState => _auth.authStateChanges();
  static Future<void> login(String e, String p) =>
      _auth.signInWithEmailAndPassword(email: e, password: p);
  static Future<void> register(String e, String p) =>
      _auth.createUserWithEmailAndPassword(email: e, password: p);
  static Future<void> logout() => _auth.signOut();

  static CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection('users').doc(user.uid).collection('resumes');

  static Stream<List<Resume>> resumes() => _col.orderBy('updatedAt', descending: true)
      .snapshots().map((s) => s.docs.map((d) => Resume.fromMap(d.id, d.data())).toList());

  static Future<String> save(Resume r) async {
    final data = {...r.toMap(), 'updatedAt': FieldValue.serverTimestamp()};
    if (r.id.isEmpty) return (await _col.add(data)).id;
    await _col.doc(r.id).set(data, SetOptions(merge: true));
    return r.id;
  }

  static Future<void> delete(String id) => _col.doc(id).delete();
}
