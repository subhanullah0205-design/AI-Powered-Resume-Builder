# AI-Powered Resume Builder

Flutter + Firebase + OpenAI mobile app that helps interns and professionals build resumes quickly.

![Overview](docs/images/resume_1_overview.png)

## Features
- Firebase email/password authentication; resumes saved per user in Cloud Firestore
- AI content generation (OpenAI): professional summary, improved experience bullets, role-tailored skill suggestions
- 3 pre-designed templates (Modern, Classic, Minimal) with live preview
- Import from LinkedIn: paste your profile text and AI fills in the fields
- Export / share / print as PDF

![Features](docs/images/resume_2_features.png)
![Tech stack](docs/images/resume_3_techstack.png)

*Images are design previews of the app screens.*

## Structure
```
lib/main.dart                       auth gate
lib/models.dart                     Resume model
lib/services/ai_service.dart        OpenAI calls (summary, bullets, skills, profile parsing)
lib/services/firebase_service.dart  auth + resumes CRUD
lib/services/pdf_service.dart       PDF templates
lib/screens/                        login, home, editor, preview
```

## Setup
1. `flutter create --org pk.internee --project-name ai_resume_builder .` (keep existing lib/ and pubspec.yaml)
2. `flutter pub get`
3. Firebase: create project, enable Email/Password, create Firestore; `flutterfire configure` and use `DefaultFirebaseOptions.currentPlatform` in `main.dart`.
4. Android: INTERNET permission, minSdk 23.
5. Get an OpenAI API key and run:
   `flutter run --dart-define=OPENAI_KEY=sk-your-key`
6. Build: `flutter build apk --release --dart-define=OPENAI_KEY=sk-your-key`

## Security note
A key compiled into an app can be extracted. Never commit it. For production, call OpenAI from a Firebase Cloud Function and keep the key on the server.

## LinkedIn import
LinkedIn does not offer free open access to profile data, so the app imports by pasting profile text, which AI turns into structured fields.

## Firestore rules
```
rules_version = '2';
service cloud.firestore { match /databases/{db}/documents {
  match /users/{uid}/{document=**} { allow read, write: if request.auth.uid == uid; }
}}
```

## Author
Subhan Ullah
